# Escreva um programa que pede ao usuário dois números e exiba no final a soma deles:
# OUTPUT ESPERADO:

# Digite um número: 10
# Digite outro número: 30
# A soma entre 10 e 30 é: 40


# ------------------------------------------ ESCREVA SEU CÓDIGO ABAIXO -----------------------------------------------------------
numero1 = int(input("digite um numero"))
numero2 = int(input("digite um numero"))

soma = numero1 + numero2

print(soma)